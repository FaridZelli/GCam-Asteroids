/* noise_profile.cc
  Note: gradient_slope --> gradient of API s_measured parameter
        offset_slope --> o_model of API s_measured parameter
        gradient_intercept--> gradient of API o_measured parameter
        offset_intercept --> o_model of API o_measured parameter
  Note: SENSOR_NOISE_PROFILE in Android Developers doc uses
        N(x) = sqrt(Sx + O), where 'S' is 's_measured' & 'O' is 'o_measured'
*/
.profile = {
    .noise_coefficients_r = {.gradient_slope = 1.1146156613131433e-06,
                             .offset_slope = 6.036081275149641e-06,
                             .gradient_intercept = 3.6356197963352e-12,
                             .offset_intercept = 5.074901408823351e-07},
    .noise_coefficients_gr = {.gradient_slope = 1.11944472385471e-06,
                              .offset_slope = 8.924026819938942e-06,
                              .gradient_intercept = 3.646116952802215e-12,
                              .offset_intercept = 4.82422254389145e-07},
    .noise_coefficients_gb = {.gradient_slope = 1.1269518187615289e-06,
                              .offset_slope = 9.12372032465769e-06,
                              .gradient_intercept = 3.663172577979543e-12,
                              .offset_intercept = 4.846269911143858e-07},
    .noise_coefficients_b = {.gradient_slope = 1.1181624567757034e-06,
                             .offset_slope = 8.319659452526407e-06,
                             .gradient_intercept = 3.654918279730269e-12,
                             .offset_intercept = 5.126503294403391e-07}},