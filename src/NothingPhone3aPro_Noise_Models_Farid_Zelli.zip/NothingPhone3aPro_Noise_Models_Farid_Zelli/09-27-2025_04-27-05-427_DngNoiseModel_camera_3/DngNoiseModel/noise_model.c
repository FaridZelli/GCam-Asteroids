/* Generated test code to dump a table of data for external validation
* of the noise model parameters.
*/
#include <stdio.h>
#include <assert.h>
double compute_noise_model_entry_S(int plane, int sens);
double compute_noise_model_entry_O(int plane, int sens);
int main(void) {
    for (int plane = 0; plane < 4; plane++) {
        for (int sens = 200; sens <= 3200; sens += 100) {
            double o = compute_noise_model_entry_O(plane, sens);
            double s = compute_noise_model_entry_S(plane, sens);
            printf("%d,%d,%lf,%lf\n", plane, sens, o, s);
        }
    }
    return 0;
}

/* Generated functions to map a given sensitivity to the O and S noise
* model parameters in the DNG noise model. The planes are in
* R, Gr, Gb, B order.
*/
double compute_noise_model_entry_S(int plane, int sens) {
    static double noise_model_A[] = { 1.11461566131e-06,1.11944472385e-06,1.12695181876e-06,1.11816245678e-06 };
    static double noise_model_B[] = { 6.03608127515e-06,8.92402681994e-06,9.12372032466e-06,8.31965945253e-06 };
    double A = noise_model_A[plane];
    double B = noise_model_B[plane];
    double s = A * sens + B;
    return s < 0.0 ? 0.0 : s;
}

double compute_noise_model_entry_O(int plane, int sens) {
    static double noise_model_C[] = { 3.63561979634e-12,3.6461169528e-12,3.66317257798e-12,3.65491827973e-12 };
    static double noise_model_D[] = { 5.07490140882e-07,4.82422254389e-07,4.84626991114e-07,5.1265032944e-07 };
    double digital_gain = (sens / 3200.0) < 1.0 ? 1.0 : (sens / 3200.0);
    double C = noise_model_C[plane];
    double D = noise_model_D[plane];
    double o = C * sens * sens + D * digital_gain * digital_gain;
    return o < 0.0 ? 0.0 : o;
}
