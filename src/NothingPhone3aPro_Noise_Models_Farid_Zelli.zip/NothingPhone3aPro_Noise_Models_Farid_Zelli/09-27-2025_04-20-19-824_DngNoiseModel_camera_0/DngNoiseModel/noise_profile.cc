/* noise_profile.cc
  Note: gradient_slope --> gradient of API s_measured parameter
        offset_slope --> o_model of API s_measured parameter
        gradient_intercept--> gradient of API o_measured parameter
        offset_intercept --> o_model of API o_measured parameter
  Note: SENSOR_NOISE_PROFILE in Android Developers doc uses
        N(x) = sqrt(Sx + O), where 'S' is 's_measured' & 'O' is 'o_measured'
*/
.profile = {
    .noise_coefficients_r = {.gradient_slope = 3.64404478907182e-07,
                             .offset_slope = 2.5046974336701393e-06,
                             .gradient_intercept = 4.200548288120092e-13,
                             .offset_intercept = 6.896464322710604e-07},
    .noise_coefficients_gr = {.gradient_slope = 3.621313844711646e-07,
                              .offset_slope = 2.294047853850197e-06,
                              .gradient_intercept = 4.0095301080241313e-13,
                              .offset_intercept = 6.881853626362105e-07},
    .noise_coefficients_gb = {.gradient_slope = 3.627982712427187e-07,
                              .offset_slope = 2.439283328704672e-06,
                              .gradient_intercept = 4.2543629885194777e-13,
                              .offset_intercept = 6.814219804287031e-07},
    .noise_coefficients_b = {.gradient_slope = 3.660871966830583e-07,
                             .offset_slope = 6.643194229595166e-07,
                             .gradient_intercept = 4.508819562559364e-13,
                             .offset_intercept = 6.932932789526781e-07}},