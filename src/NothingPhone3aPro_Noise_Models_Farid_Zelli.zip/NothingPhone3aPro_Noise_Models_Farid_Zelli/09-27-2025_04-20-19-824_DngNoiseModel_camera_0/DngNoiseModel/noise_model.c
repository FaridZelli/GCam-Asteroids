/* Generated test code to dump a table of data for external validation
* of the noise model parameters.
*/
#include <stdio.h>
#include <assert.h>
double compute_noise_model_entry_S(int plane, int sens);
double compute_noise_model_entry_O(int plane, int sens);
int main(void) {
    for (int plane = 0; plane < 4; plane++) {
        for (int sens = 100; sens <= 800; sens += 100) {
            double o = compute_noise_model_entry_O(plane, sens);
            double s = compute_noise_model_entry_S(plane, sens);
            printf("%d,%d,%lf,%lf\n", plane, sens, o, s);
        }
    }
    return 0;
}

/* Generated functions to map a given sensitivity to the O and S noise
* model parameters in the DNG noise model. The planes are in
* R, Gr, Gb, B order.
*/
double compute_noise_model_entry_S(int plane, int sens) {
    static double noise_model_A[] = { 3.64404478907e-07,3.62131384471e-07,3.62798271243e-07,3.66087196683e-07 };
    static double noise_model_B[] = { 2.50469743367e-06,2.29404785385e-06,2.4392833287e-06,6.6431942296e-07 };
    double A = noise_model_A[plane];
    double B = noise_model_B[plane];
    double s = A * sens + B;
    return s < 0.0 ? 0.0 : s;
}

double compute_noise_model_entry_O(int plane, int sens) {
    static double noise_model_C[] = { 4.20054828812e-13,4.00953010802e-13,4.25436298852e-13,4.50881956256e-13 };
    static double noise_model_D[] = { 6.89646432271e-07,6.88185362636e-07,6.81421980429e-07,6.93293278953e-07 };
    double digital_gain = (sens / 12800.0) < 1.0 ? 1.0 : (sens / 12800.0);
    double C = noise_model_C[plane];
    double D = noise_model_D[plane];
    double o = C * sens * sens + D * digital_gain * digital_gain;
    return o < 0.0 ? 0.0 : o;
}
