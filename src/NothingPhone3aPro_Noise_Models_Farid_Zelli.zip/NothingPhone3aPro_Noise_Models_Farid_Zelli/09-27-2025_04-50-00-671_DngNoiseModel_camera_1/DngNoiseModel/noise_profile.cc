/* noise_profile.cc
  Note: gradient_slope --> gradient of API s_measured parameter
        offset_slope --> o_model of API s_measured parameter
        gradient_intercept--> gradient of API o_measured parameter
        offset_intercept --> o_model of API o_measured parameter
  Note: SENSOR_NOISE_PROFILE in Android Developers doc uses
        N(x) = sqrt(Sx + O), where 'S' is 's_measured' & 'O' is 'o_measured'
*/
.profile = {
    .noise_coefficients_r = {.gradient_slope = 7.371170492019272e-07,
                             .offset_slope = 4.465748511803012e-06,
                             .gradient_intercept = 1.0856255801707583e-12,
                             .offset_intercept = 5.028197190641687e-07},
    .noise_coefficients_gr = {.gradient_slope = 7.425459077097095e-07,
                              .offset_slope = 3.010969605140014e-06,
                              .gradient_intercept = 1.0467371674052998e-12,
                              .offset_intercept = 4.874346916260736e-07},
    .noise_coefficients_gb = {.gradient_slope = 7.433266995500773e-07,
                              .offset_slope = 3.735334132574932e-06,
                              .gradient_intercept = 1.0446989436194212e-12,
                              .offset_intercept = 4.966124362881879e-07},
    .noise_coefficients_b = {.gradient_slope = 7.438501881052689e-07,
                             .offset_slope = 2.6035854831664275e-06,
                             .gradient_intercept = 1.0737408501889382e-12,
                             .offset_intercept = 4.956971852326713e-07}},