/* noise_profile.cc
  Note: gradient_slope --> gradient of API s_measured parameter
        offset_slope --> o_model of API s_measured parameter
        gradient_intercept--> gradient of API o_measured parameter
        offset_intercept --> o_model of API o_measured parameter
  Note: SENSOR_NOISE_PROFILE in Android Developers doc uses
        N(x) = sqrt(Sx + O), where 'S' is 's_measured' & 'O' is 'o_measured'
*/
.profile = {
    .noise_coefficients_r = {.gradient_slope = 3.5905056384550685e-06,
                             .offset_slope = 2.6795270970143037e-06,
                             .gradient_intercept = 4.069882733173506e-11,
                             .offset_intercept = 4.6412638328748226e-07},
    .noise_coefficients_gr = {.gradient_slope = 3.5259273929106013e-06,
                              .offset_slope = 1.25209771330133e-05,
                              .gradient_intercept = 4.1094875230964615e-11,
                              .offset_intercept = 4.315920091108653e-07},
    .noise_coefficients_gb = {.gradient_slope = 3.5234195941821347e-06,
                              .offset_slope = 1.2191977887406115e-05,
                              .gradient_intercept = 4.123052488429821e-11,
                              .offset_intercept = 4.3421835179547716e-07},
    .noise_coefficients_b = {.gradient_slope = 3.615388664702443e-06,
                             .offset_slope = 3.5194841686915496e-06,
                             .gradient_intercept = 3.9945674830537446e-11,
                             .offset_intercept = 4.532027087010836e-07}},