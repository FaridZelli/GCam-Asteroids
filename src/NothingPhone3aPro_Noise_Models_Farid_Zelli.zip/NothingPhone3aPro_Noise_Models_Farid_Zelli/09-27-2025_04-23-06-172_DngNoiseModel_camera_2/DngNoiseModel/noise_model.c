/* Generated test code to dump a table of data for external validation
* of the noise model parameters.
*/
#include <stdio.h>
#include <assert.h>
double compute_noise_model_entry_S(int plane, int sens);
double compute_noise_model_entry_O(int plane, int sens);
int main(void) {
    for (int plane = 0; plane < 4; plane++) {
        for (int sens = 50; sens <= 800; sens += 100) {
            double o = compute_noise_model_entry_O(plane, sens);
            double s = compute_noise_model_entry_S(plane, sens);
            printf("%d,%d,%lf,%lf\n", plane, sens, o, s);
        }
    }
    return 0;
}

/* Generated functions to map a given sensitivity to the O and S noise
* model parameters in the DNG noise model. The planes are in
* R, Gr, Gb, B order.
*/
double compute_noise_model_entry_S(int plane, int sens) {
    static double noise_model_A[] = { 3.59050563846e-06,3.52592739291e-06,3.52341959418e-06,3.6153886647e-06 };
    static double noise_model_B[] = { 2.67952709701e-06,1.2520977133e-05,1.21919778874e-05,3.51948416869e-06 };
    double A = noise_model_A[plane];
    double B = noise_model_B[plane];
    double s = A * sens + B;
    return s < 0.0 ? 0.0 : s;
}

double compute_noise_model_entry_O(int plane, int sens) {
    static double noise_model_C[] = { 4.06988273317e-11,4.1094875231e-11,4.12305248843e-11,3.99456748305e-11 };
    static double noise_model_D[] = { 4.64126383287e-07,4.31592009111e-07,4.34218351795e-07,4.53202708701e-07 };
    double digital_gain = (sens / 800.0) < 1.0 ? 1.0 : (sens / 800.0);
    double C = noise_model_C[plane];
    double D = noise_model_D[plane];
    double o = C * sens * sens + D * digital_gain * digital_gain;
    return o < 0.0 ? 0.0 : o;
}
